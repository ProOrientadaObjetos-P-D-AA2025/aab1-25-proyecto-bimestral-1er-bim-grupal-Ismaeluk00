package admisionesutpl;

public class Carrera {
    private String nombre;
    private String tipo; // "Examen" o "Diagnostico"
    private double puntajeMinimo;
    private double puntajeNivelacion;
    private int cupos = 64;
    private int cuposAdicionales = 5;

    public Carrera(String nombre, String tipo, double puntajeMinimo, double puntajeNivelacion) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.puntajeMinimo = puntajeMinimo;
        this.puntajeNivelacion = puntajeNivelacion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPuntajeMinimo() {
        return puntajeMinimo;
    }

    public double getPuntajeNivelacion() {
        return puntajeNivelacion;
    }

    public int getCupos() {
        return cupos;
    }

    public int getCuposAdicionales() {
        return cuposAdicionales;
    }
}