package admisionesutpl;

import java.util.Scanner;

public class AdmisionesUTPL {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Controlador controlador = new Controlador();
        controlador.menu(scanner);
    }
}
