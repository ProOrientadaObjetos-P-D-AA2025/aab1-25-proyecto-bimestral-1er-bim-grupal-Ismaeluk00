package admisionesutpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Controlador {

    private List<Carrera> carreras;
    private List<Postulante> postulantes;

    public Controlador() {
        carreras = new ArrayList<>();
        postulantes = new ArrayList<>();
        cargarCarreras();
    }

    private void cargarCarreras() {
        carreras.add(new Carrera("Administración de Empresas", "Examen", 80, 0));
        carreras.add(new Carrera("Agropecuaria", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Alimentos", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Artes Escénicas", "Examen", 70, 0));
        carreras.add(new Carrera("Artes Visuales", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Biología", "Examen", 76, 0));
        carreras.add(new Carrera("Computación", "Examen", 82, 0));
        carreras.add(new Carrera("Contabilidad y Auditoría", "Examen", 79, 0));
        carreras.add(new Carrera("Derecho", "Examen", 80, 0));
        carreras.add(new Carrera("Economía", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Finanzas", "Examen", 79, 0));
        carreras.add(new Carrera("Geología", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Ingeniería Ambiental", "Examen", 81, 0));
        carreras.add(new Carrera("Ingeniería Química", "Examen", 83, 0));
        carreras.add(new Carrera("Pedagogía de los Idiomas Nacionales y Extranjeros", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Psicopedagogía", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Telecomunicaciones", "Examen", 80, 0));
        carreras.add(new Carrera("Arquitectura", "Examen", 82, 0));
        carreras.add(new Carrera("Bioquímica y Farmacia", "Examen", 85, 0));
        carreras.add(new Carrera("Enfermería", "Examen", 84, 0));
        carreras.add(new Carrera("Fisioterapia", "Examen", 83, 0));
        carreras.add(new Carrera("Gastronomía", "Diagnostico", 0, 30));
        carreras.add(new Carrera("Ingeniería Civil", "Examen", 82, 0));
        carreras.add(new Carrera("Ingeniería Industrial", "Examen", 81, 0));
        carreras.add(new Carrera("Medicina", "Examen", 90, 0));
        carreras.add(new Carrera("Nutrición y Dietética", "Examen", 83, 0));
        carreras.add(new Carrera("Psicología", "Examen", 79, 0));
        carreras.add(new Carrera("Psicología Clínica", "Examen", 82, 0));
    }

    public void menu(Scanner scanner) {
        int opcion;
        do {
            System.out.println("\n--- MENÚ DE OPCIONES ---");
            System.out.println("1. Registrar postulante");
            System.out.println("2. Procesar admisión");
            System.out.println("3. Mostrar resultados");
            System.out.println("4. Estadísticas");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = leerEntero(scanner);
            switch (opcion) {
                case 1 -> registrarPostulante(scanner);
                case 2 -> procesarAdmisiones();
                case 3 -> mostrarResultados();
                case 4 -> mostrarEstadisticas();
                case 0 -> System.out.println("Gracias por usar el sistema.");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }

    private void registrarPostulante(Scanner scanner) {
        scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Cédula: ");
        String cedula = scanner.nextLine();
        System.out.print("Puntaje (0-100): ");
        double puntaje = leerDouble(scanner);
        boolean discapacidad = leerBoolean(scanner, "¿Tiene discapacidad?");
        boolean abanderado = leerBoolean(scanner, "¿Es abanderado?");
        boolean afin = leerBoolean(scanner, "¿Tiene bachillerato afín?");

        System.out.println("Carreras disponibles:");
        for (int i = 0; i < carreras.size(); i++) {
            System.out.printf("%2d. %s (%s)%n", i + 1, carreras.get(i).getNombre(), carreras.get(i).getTipo());
        }
        System.out.print("Seleccione número de carrera: ");
        int numCarrera = leerEntero(scanner) - 1;

        if (numCarrera >= 0 && numCarrera < carreras.size()) {
            postulantes.add(new Postulante(nombre, cedula, puntaje, discapacidad, abanderado, afin, carreras.get(numCarrera)));
            System.out.println("Postulante registrado.");
        } else {
            System.out.println("Carrera no válida.");
        }
    }

    private void procesarAdmisiones() {
        for (Carrera c : carreras) {
            List<Postulante> porCarrera = postulantes.stream()
                .filter(p -> p.getCarreraAplicada().equals(c)).toList();

            List<Postulante> ordenados = new ArrayList<>(porCarrera);
            ordenados.sort((a, b) -> Double.compare(b.getMerito(), a.getMerito()));

            int admitidos = 0;
            for (Postulante p : ordenados) {
                if (c.getTipo().equalsIgnoreCase("Examen")) {
                    double minimo = c.getPuntajeMinimo();
                    if (p.getPuntaje() >= minimo) {
                        if (admitidos < c.getCupos() + c.getCuposAdicionales()) {
                            p.setAdmitido(true);
                            admitidos++;
                        }
                    }
                } else if (c.getTipo().equalsIgnoreCase("Diagnostico")) {
                    p.setAdmitido(true);
                    if (p.getPuntaje() < c.getPuntajeNivelacion()) {
                        p.setRequiereNivelacion(true);
                    }
                }
            }
        }
        System.out.println("Proceso de admisión finalizado.");
    }

    private void mostrarResultados() {
        for (Postulante p : postulantes) {
            System.out.printf("%s | %s | Puntaje: %.2f | Mérito: %.2f | Admitido: %s",
                p.getNombre(), p.getCarreraAplicada().getNombre(), p.getPuntaje(),
                p.getMerito(), p.isAdmitido() ? "Sí" : "No");
            if (p.isRequiereNivelacion()) System.out.print(" (Nivelación requerida)");
            System.out.println();
        }
    }

    private void mostrarEstadisticas() {
        for (Carrera c : carreras) {
            long total = postulantes.stream().filter(p -> p.getCarreraAplicada().equals(c)).count();
            long admitidos = postulantes.stream().filter(p -> p.getCarreraAplicada().equals(c) && p.isAdmitido()).count();
            System.out.printf("%s: %d postulantes | %d admitidos", c.getNombre(), total, admitidos);
            if (total < c.getCupos() / 2) {
                System.out.print(" --> Menos del 50% de cupos ocupados");
            }
            if (admitidos > c.getCupos()) {
                System.out.print(" --> Uso de cupos adicionales");
            }
            System.out.println();
        }
    }

    private int leerEntero(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.print("Ingrese un número entero válido: ");
            scanner.next();
        }
        return scanner.nextInt();
    }

    private double leerDouble(Scanner scanner) {
        while (!scanner.hasNextDouble()) {
            System.out.print("Ingrese un número decimal válido: ");
            scanner.next();
        }
        return scanner.nextDouble();
    }

    private boolean leerBoolean(Scanner scanner, String mensaje) {
        System.out.print(mensaje + " (sí/no): ");
        String respuesta = scanner.next().trim().toLowerCase();
        while (!respuesta.equals("si") && !respuesta.equals("no") && !respuesta.equals("s") && !respuesta.equals("n")) {
            System.out.print("Por favor escriba 'sí' o 'no': ");
            respuesta = scanner.next().trim().toLowerCase();
        }
        return respuesta.equals("si") || respuesta.equals("s");
    }
}