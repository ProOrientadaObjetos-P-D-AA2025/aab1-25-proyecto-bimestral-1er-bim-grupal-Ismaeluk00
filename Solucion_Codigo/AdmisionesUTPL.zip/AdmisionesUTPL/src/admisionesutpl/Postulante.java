package admisionesutpl;

public class Postulante {
    private String nombre;
    private String cedula;
    private double puntaje;
    private boolean discapacidad;
    private boolean abanderado;
    private boolean bachillerAfin;
    private Carrera carreraAplicada;
    private double merito;
    private boolean admitido;
    private boolean requiereNivelacion;

    public Postulante(String nombre, String cedula, double puntaje, boolean discapacidad,
                      boolean abanderado, boolean bachillerAfin, Carrera carreraAplicada) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.puntaje = puntaje;
        this.discapacidad = discapacidad;
        this.abanderado = abanderado;
        this.bachillerAfin = bachillerAfin;
        this.carreraAplicada = carreraAplicada;
        this.merito = calcularMerito();
    }

    public double calcularMerito() {
        double merito = puntaje;
        if (abanderado) merito += 5;
        if (bachillerAfin) merito += 2;
        if (discapacidad) merito += 3;
        return merito;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public double getPuntaje() {
        return puntaje;
    }

    public boolean tieneDiscapacidad() {
        return discapacidad;
    }

    public Carrera getCarreraAplicada() {
        return carreraAplicada;
    }

    public double getMerito() {
        return merito;
    }

    public void setAdmitido(boolean admitido) {
        this.admitido = admitido;
    }

    public boolean isAdmitido() {
        return admitido;
    }

    public void setRequiereNivelacion(boolean r) {
        this.requiereNivelacion = r;
    }

    public boolean isRequiereNivelacion() {
        return requiereNivelacion;
    }
}
